java -cp nxt.jar:lib/*:conf nxt.VerifyTrace
